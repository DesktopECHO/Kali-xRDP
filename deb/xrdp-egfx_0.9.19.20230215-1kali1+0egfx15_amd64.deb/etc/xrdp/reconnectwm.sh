#!/bin/sh
# unlock session when reconnecting. works in conjunction with multisession workarounds

get_unit_name()
{
    if [ -z "$XDG_RUNTIME_DIR" ]; then
        echo "** Warning - no $XDG_RUNTIME_DIR. Using systemd default" >&2
        XDG_RUNTIME_DIR=/run/user/$(id -u)
    fi
    if [ -z "$DISPLAY" ]; then
        echo "** Warning - no DISPLAY. Assuming test mode" >&2
        unit_name=systemd-session@test
    else
        unit_name=systemd-session@${DISPLAY##*:} ; # e.g. systemd-session@10.0
        unit_name=${unit_name%.*} ; # e.g. systemd-session@10
    fi
}

get_session_runtime_dir()
{
    session_runtime_dir=$XDG_RUNTIME_DIR/${1%%@*}-${1##*@}
}

[ -z "$XDG_RUNTIME_DIR" ] && XDG_RUNTIME_DIR=/run/user/$(id -u)

get_unit_name
get_session_runtime_dir $unit_name

test -e "$session_runtime_dir" && \
	eval $(/etc/xrdp/systemd_user_context.sh get)

test -e $XDG_RUNTIME_DIR/login-session-id && \
	loginctl unlock-session $(cat $XDG_RUNTIME_DIR/login-session-id)

# Write procedures here you want to execute on reconnect
