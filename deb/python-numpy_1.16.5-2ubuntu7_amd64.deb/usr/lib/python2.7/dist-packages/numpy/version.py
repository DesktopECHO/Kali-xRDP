
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.5'
version = '1.16.5'
full_version = '1.16.5'
git_revision = 'cbdc3b7477aa0b497406bbb2df1025bed290f3cb'
release = True

if not release:
    version = full_version
